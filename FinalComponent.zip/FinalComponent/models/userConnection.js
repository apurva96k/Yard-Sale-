var mongoose = require('mongoose');
var userConnection = function(userID,connection,rsvp)
{
var userConnectionModel = {userID:userID,connectionData:connection,rsvp:rsvp};
return userConnectionModel;

};


module.exports.userConnectionSchema = new mongoose.Schema({
userID:String,
connectionData:{
  connectionID:String,
    connectionName:String,
    topic:String
},

rsvp: String
});


module.exports.userConnection = userConnection;
