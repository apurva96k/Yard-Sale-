var mongoose = require('mongoose');

var userConnectionModel = require('../models/userConnection');

let userProfile = function(userID) {

    let userProfileModel = {
        userID: userID,
        userConnections: userConnections
    };
    return userProfileModel;
};
var userConnectionDB = require("../utility/userConnectionDB")

//this adds a connection to the database
module.exports.addConnection = async function(connectionID, db, userID, rsvp, subdb) {

    userConnectionModel = require('../models/userConnection');
    connectionDB = require('../utility/connectionDB');
    let connection = await connectionDB.getConnection(subdb, connectionID);
    userConnectionModel = await userConnectionModel.userConnection(userID, connection, rsvp);
    db.find({}).then(data => {
        for (let i = 0; i < data.length; i++) {

            if (data[i].connectionData.connectionID === connectionID) {

                return 0;
            }
        }
    })
    await userConnectionDB.addConnection(db, userConnectionModel);
    return 1;

}
module.exports.checkUserExists = async function(db, userID) {

    return new Promise((resolve, reject) => {
        db.find({}).then(data => {
            var flag;

            for (let i = 0; i < data.length; i++) {


                if (data[i].userID == userID) {
                    flag = 0;
                    resolve(flag);
                } else {
                    flag = 1;
                    resolve(flag);
                }

            }


        }).catch(err => {
            return reject(err);
        })

    })

}

//this removes a connection from the database
module.exports.removeConnection = function(connectionID, userID, db) {
    return new Promise((resolve, reject) => {
        db.deleteOne({
            userID: userID,
            "connectionData.connectionID": connectionID,
        }).then(data => {
            resolve(data);
        }).catch(err => {
            return reject(err);
        })
    })
}

module.exports.removeuserConnection = function(connectionID, userID, db) {
    return new Promise((resolve, reject) => {
        db.deleteOne({
            userID: userID,
            connectionID: connectionID,
        }).then(data => {
            resolve(data);
        }).catch(err => {
            return reject(err);
        })
    })
}

// fetching the connections to which user has rsvpd
module.exports.getConnections = function(db, userID) {
    return new Promise((resolve, reject) => {
        db.find({
            userID: userID
        }).then(data => {
            resolve(data);
        }).catch(err => {
            return reject(err);
        })
    })
}
//updating connection information
module.exports.updateConnection = function(db, connectionID, update) {
    return new Promise((resolve, reject) => {
        db.updateOne({
            connectionID: connectionID
        }, {
            $set: update
        }).then(data => {
            resolve(data)
        }).catch(err => {
            return reject(err);
        })
    })
}
module.exports.updateuserConnection = function(db, connectionID, update) {
    return new Promise((resolve, reject) => {
        db.updateOne({
            "connectionData.connectionID": connectionID
        }, {
            $set: {
                connectionData: update
            }
        }).then(data => {
            resolve(data)
        }).catch(err => {
            return reject(err);
        })
    })
}
module.exports.emptyProfile = function(userID, db) {
    return new Promise((resolve, reject) => {
        db.deleteMany({
            userID: userID

        }).then(data => {
            resolve(data);
        }).catch(err => {
            return reject(err);
        })
    })
}

module.exports.userProfile = userProfile;
