var mongoose = require('mongoose');
var user = function(userID, firstName, lastName, email, addressline1, addressline2, city, state, zipcode, country, password, salt) {
    var userModel = {
        userID: userID,
        firstName: firstName,
        lastName: lastName,
        email: email,
        addressline1: addressline1,
        addressline2: addressline2,
        city: city,
        state: state,
        country: country,
        zipcode: zipcode,
        password: password,
        salt: salt
    };
    return userModel;

};
module.exports.userSchema = new mongoose.Schema({
    userID: String,
    firstName: String,
    lastName: String,
    email: String,
    addressline1: String,
    addressline2: String,
    city: String,
    state: String,
    zipcode: String,
    country: String,
    password: String,
    salt: String
});

module.exports.user = user;
