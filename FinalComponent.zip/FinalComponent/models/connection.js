var mongoose = require('mongoose');

var connection = function(connectionID, connectionName, topic, details, date, time, hostName, address) {
    var connectionModel = {
        connectionID: connectionID,
        connectionName: connectionName,
        topic: topic,
        details: details,
        date: date,
        time: time,
        hostName: hostName,
        address: address,
        imgUrl: getImgUrl(connectionID)
    };
    return connectionModel;

};
var getImgUrl = function(connectionID) {
    if (connectionID != null) {
        return "/assets/images/" + connectionID + ".jpg";
    } else {
        return "/assets/images/spidy.jpg";
    }
};

module.exports.subconnectionsSchema = new mongoose.Schema({

    connectionID: String,
    connectionName: String,
    topic: String,
    details: String,
    date: String,
    time: String,
    hostName: String,
    address: String,
    userID: String
});

module.exports.connectionsSchema = new mongoose.Schema({

    connectionID: String,
    connectionName: String,
    userID: String
});

module.exports.connection = connection;
