var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/Milestone4', {
    useNewUrlParser: true
});
let userProfile = require('../models/userProfile.js');
var userModel1 = require('../models/user.js')
var connectionModel = require('../models/connection.js')
var userConnectionModel1 = require('../models/userConnection.js');
var express = require('express');
var connectionDB = require('../utility/connectionDB.js');

var userConnectionDB = require('../utility/userConnectionDB.js');
var userDB = require('../utility/userDB.js');
var router = express.Router();
var bodyParser = require('body-parser')
var session = require('express-session');
var cookieParser = require('cookie-parser');
const {
    check,
    validationResult
} = require('express-validator/check');

var urlEncoderParser = bodyParser.urlencoded({
    extended: false
});
router.use(cookieParser());
router.use(session({
    secret: "Secret!"
}));

var usersModel = mongoose.model('users', userModel1.userSchema, 'userData');
var Connections = mongoose.model('connections', connectionModel.connectionsSchema, 'connections');
var Subconnections = mongoose.model('subconnections', connectionModel.subconnectionsSchema, 'subconnections');
var userConnectionModel = mongoose.model('userConnections', userConnectionModel1.userConnectionSchema, 'userConnections');

//rendering connections rsvp'd by user
router.get('/myConnections', async function(request, response) {
    if (request.session.theUser) {
        let savedConnections = await userDB.updateUserProfileItems(userConnectionModel, request.session.theUser.userID);
        response.render('myConnections', {
            allSavedItems1: savedConnections,
            userMessage: '',
            currentUser: 'yes',
            currentName: request.session.theUser.firstName
        });
    } else {
        response.render('index', {
            currentUser: 'no',
            currentName: 'Please Sign in!'
        })
    }
})



router.post('/myConnections', urlEncoderParser, async function(request, response) {

    let message = '';
    var userData = request.session.theUser;
    // connection will get added when user will rsvp
    if (request.body.action == 'Maybe' || request.body.action == 'Yes' || request.body.action == 'No') {
        if (!request.session.theUser) {
            response.render('login', {
                currentUser: 'no',
                currentName: 'Please Sign in!',
                loginerror: "Please sign in to RSVP for this event! "
            });
        } else {

          // if connection is already in the user connections list, rsvp will be updated
            let flag = await userProfile.addConnection(request.body.connectionID, userConnectionModel, request.session.theUser.email,
                request.body.action, Subconnections);
            if (flag === 1) {

                await userConnectionDB.updateRSVP(userConnectionModel, request.body.connectionID,
                    request.session.theUser.email, request.body.action);

            }
            let savedConnections = await userDB.updateUserProfileItems(userConnectionModel, request.session.theUser.userID);
            request.session.userProfile = savedConnections;
            response.render('myConnections', {
                allSavedItems1: savedConnections,
                userMessage: message,
                currentUser: 'yes',
                currentName: request.session.theUser.firstName
            });
        }

    } else if (request.body.action == 'updateProfile') {
        if (!request.session.theUser) {
            response.render('index', {
                currentUser: 'no',
                currentName: 'Please Sign in!'
            });
        } else {
            userProfile = require('../models/userProfile.js');
            if (request.body.ConnectionsList) {
                if (request.body.ConnectionsList.includes(request.body.connectionID)) {
                    if (request.body.rsvp == 'Yes' || request.body.rsvp == 'No' || request.body.rsvp == 'Maybe') {
                        await userConnectionDB.updateRSVP(userConnectionModel, request.body.connectionID, request.session.theUser.email, request.body.rsvp);
                    }
                    let savedConnections = await userDB.updateUserProfileItems(userConnectionModel, request.session.theUser.email);
                    request.session.userProfile = savedConnections;

                    response.render('myConnections', {
                        allSavedItems1: savedConnections,
                        userMessage: message,
                        currentUser: 'Yes',
                        currentName: request.session.theUser.firstName
                    });

                } else {
                    let savedConnections = userDB.updateUserProfileItems(userConnectionModel, request.session.theUser.email);
                    request.session.userProfile = savedConnections;
                    response.render('myConnections', {
                        allSavedItems1: savedConnections,
                        userMessage: message,
                        currentUser: 'Yes',
                        currentName: request.session.theUser.firstName
                    });

                }
            } else {
                let savedConnections = userDB.updateUserProfileItems(userConnectionModel, request.session.theUser.email);
                request.session.userProfile = savedConnections;
                response.render('myConnections', {
                    allSavedItems1: savedConnections,
                    userMessage: message,
                    currentUser: 'Yes',
                    currentName: request.session.theUser.firstName
                });

            }
        }

    } else {

        if (!request.session.theUser) {
            request.session.theUser = currentUser;
        }
        //connections will be deleted from user connections
        if (request.body.action == 'delete') {
            userProfile = require('../models/userProfile.js');

            await userProfile.removeConnection(request.body.connectionID, request.session.theUser.userID, userConnectionModel);
            let savedConnections1 = await userDB.updateUserProfileItems(userConnectionModel, request.session.theUser.userID);
            request.session.userProfile = savedConnections1;
            response.render('myConnections', {
                allSavedItems1: savedConnections1,
                userMessage: message,
                currentUser: 'Yes',
                currentName: request.session.theUser.firstName
            });
        }

    }

});




module.exports = router;
