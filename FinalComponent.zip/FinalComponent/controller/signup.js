var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/Milestone4', {
    useNewUrlParser: true
});
let userProfile = require('../models/userProfile.js');
var userModel1 = require('../models/user.js')
var connectionModel = require('../models/connection.js')
var userConnectionModel1 = require('../models/userConnection.js');
var express = require('express');
var connectionDB = require('../utility/connectionDB.js');
var userConnectionDB = require('../utility/userConnectionDB.js');
var userDB = require('../utility/userDB.js');
var router = express.Router();
var bodyParser = require('body-parser')
var session = require('express-session');
var cookieParser = require('cookie-parser');
var passwordHashDB = require('../utility/passwordHash.js');
const {
    check,
    validationResult,
    sanitizeBody
} = require('express-validator');

var urlEncoderParser = bodyParser.urlencoded({
    extended: false
});
router.use(cookieParser());
router.use(session({
    secret: "Secret!"
}));

var Users = mongoose.model('users', userModel1.userSchema, 'userData');
var Connections = mongoose.model('connections', connectionModel.connectionsSchema, 'connections');
var Subconnections = mongoose.model('subconnections', connectionModel.subconnectionsSchema, 'subconnections');
var userConnectionModel = mongoose.model('userConnections', userConnectionModel1.userConnectionSchema, 'userConnections');
//this is a get call for signup
router.get('/', function(request, response) {
    if (request.session.theUser) {
        response.render('signup', {
            currentUser: 'yes',
            currentName: request.session.theUser.firstName,
            loginerror: "",
            errorMessages: ""
        })
    } else {
        response.render('signup', {
            currentUser: 'no',
            currentName: 'Please Sign in!',
            loginerror: "",
            errorMessages: ""
        })
    }
});



//a post call for signup to add the user
router.post('/', urlEncoderParser, [check('firstName').custom(name => {
            var isValid = name.match(/^([a-zA-Z]+\s)*[a-zA-Z]+$/);
            if (isValid != null) {
                return true;
            } else {
                return false;
            }
        }).withMessage('Please enter valid first name.'), sanitizeBody('firstName').trim().escape(),
        check('lastName').isAlpha().withMessage('Please enter a valid last name.'), sanitizeBody('lastName').trim().escape(),
        check('email').isEmail().normalizeEmail(),
        check('password').isLength({
            min: 8
        }).withMessage('Password length must be at least 8 characters.').isLength({
            max: 20
        }).withMessage('Password length should not exceed 20 characters.')
        .custom(name => {
            var isValid = name.match(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,20}$/);
            if (isValid != null) {
                return true;
            } else {
                return false;
            }
        }).withMessage('Password should contain atleast 1 Uppercase, 1 lowercase, 1 number, 1 special character and must not contain any spaces.'),
        check('password2').isLength({
            min: 8
        }).withMessage('Confirm Password length must be at least 8 characters.').isLength({
            max: 20
        }).
        withMessage('Confirm Password length should not exceed 20 characters.')
        .custom(name => {
            var isValid = name.match(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,20}$/);
            if (isValid != null) {
                return true;
            } else {
                return false;
            }
        }).withMessage('Confirm Password should contain atleast 1 Uppercase, 1 lowercase, 1 number, 1 special character and must not contain any spaces.')
    ],
    async function(request, response) {

        const errors = validationResult(request);

        if (!errors.isEmpty()) {
            response.render('signUp', {
                currentUser: 'no',
                currentName: 'Please Sign in!',
                loginerror: "",
                errorMessages: errors.array()
            });
        } else {

            if (request.body.password != request.body.password2) {

                response.render('signup', {
                    currentUser: 'no',
                    currentName: 'Please Sign in!',
                    loginerror: "Your Passwords don't match!"
                });

            } else {
              // checking if user exists
                var flag = await userProfile.checkUserExists(Users, request.body.email);
                var userHashedPassword = await passwordHashDB.saltHashPassword(request.body.password);
                if (flag == 1) {
                    await userDB.addUser(Users, request.body.email, request.body.firstName, request.body.lastName, request.body.email,
                        request.body.addressline1, request.body.addressline2, request.body.city, request.body.state, request.body.country,
                        request.body.zipcode, userHashedPassword.passwordHash, userHashedPassword.salt)
                    response.render('login', {
                        currentUser: 'no',
                        currentName: 'Please Sign in!',
                        loginerror: "Now that you have signed up, sign in"
                    });
                } else {
                    response.render('login', {
                        currentUser: 'no',
                        currentName: 'Please Sign in!',
                        loginerror: "You have already signed up! Please sign in!"
                    });
                }
            }
        }
    });




module.exports = router;
