var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/Milestone4', {
    useNewUrlParser: true
});
let userProfile = require('../models/userProfile.js');
var userModel1 = require('../models/user.js')
var connectionModel = require('../models/connection.js')
var userConnectionModel1 = require('../models/userConnection.js');
var express = require('express');
var connectionDB = require('../utility/connectionDB.js');
var userConnectionDB = require('../utility/userConnectionDB.js');
var userDB = require('../utility/userDB.js');
var passwordHashDB = require('../utility/passwordHash.js');
var router = express.Router();
var bodyParser = require('body-parser')
var session = require('express-session');
var cookieParser = require('cookie-parser');
const {
    check,
    validationResult
} = require('express-validator/check');
var urlEncoderParser = bodyParser.urlencoded({
    extended: false
});
router.use(cookieParser());
router.use(session({
    secret: "Secret!"
}));

var Users = mongoose.model('users', userModel1.userSchema, 'userData');
var Connections = mongoose.model('connections', connectionModel.connectionsSchema, 'connections');
var Subconnections = mongoose.model('subconnections', connectionModel.subconnectionsSchema, 'subconnections');
var userConnectionModel = mongoose.model('userConnections', userConnectionModel1.userConnectionSchema, 'userConnections');
//getting login page
router.get('/', async function(request, response) {


    if (!request.session.theUser) {
        response.render('login', {
            currentUser: 'no',
            currentName: 'Please Sign in!',
            loginerror: ""
        });

    } else {
        var userData = request.session.theUser;
        let savedConnections = await userDB.updateUserProfileItems(userConnectionModel, userData.userID)
        response.redirect('/profile/myConnections');


    }

});


// this post method is used to submit the login credentials
router.post('/', urlEncoderParser, [check('username').isEmail(), check('password')],
    async function(request, response) {
console.log("ithe aal");
        if (!validationResult(request).isEmpty()) {

            response.render('login', {
                currentUser: 'no',
                currentName: 'Please Sign in!',
                loginerror: "Please enter valid username and password!"
            });
        } else {
            if (!request.body.username || request.body.username == '') {
                response.render('login', {
                    currentUser: 'no',
                    currentName: 'Please Sign in!',
                    loginerror: "Username cannot be blank"
                });
            } else if (!request.body.password || request.body.password == '') {
                response.render('login', {
                    currentUser: 'no',
                    currentName: 'Please Sign in!',
                    loginerror: "Password cannot be blank"
                });
            } else {
                  //validating the user email
                var currentUser = await passwordHashDB.validateUserEmail(Users, request.body.username);
                if (currentUser) {
                  //validating password
                    if (await passwordHashDB.validatepassword(Users, request.body.username, request.body.password)) {
                        if (!request.session.theUser) {
                            request.session.theUser = currentUser;
                        }
                        let savedConnections = await userDB.updateUserProfileItems(userConnectionModel, currentUser.userID);
                        request.session.userProfile = savedConnections;
                    //rendering the user connection page after logging in
                        response.render('myConnections', {
                            allSavedItems1: savedConnections,
                            userMessage: '',
                            currentUser: 'yes',
                            currentName: currentUser.firstName
                        });
                    } else {
                      // if user email is invalid, render login page with error
                        response.render('login', {
                            currentUser: 'no',
                            currentName: 'Please Sign in!',
                            loginerror: "Invalid credentials." +
                                "Please enter correct details"
                        });
                    }
                } else {
                    response.render('login', {
                        currentUser: 'no',
                        currentName: 'Please Sign in!',
                        loginerror: "Invalid credentials." +
                            "Please enter correct details"
                    });
                }


            }
        }
    });



//sign out destroying session
router.get('/signout', function(request, response) {
    request.session.destroy(function(err) {
        if (err) {
            response.negotiate(err);
        }
        response.redirect('/');
    });


});



module.exports = router;
