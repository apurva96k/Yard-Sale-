var express = require('express');
var connectionDB = require('../utility/connectionDB.js');
var router = express.Router();
var userDB = require('../utility/userDB.js');
var userConnectionDB = require('../utility/userConnectionDB.js');
var connectionModel = require('../models/connection');
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/Milestone4', {
    useNewUrlParser: true
});
const {
    check,
    validationResult
} = require('express-validator/check');
var escape = require('escape-html');
var userConnectionModel1 = require('../models/userConnection.js');

var bodyParser = require('body-parser')
var session = require('express-session');
var cookieParser = require('cookie-parser');


var urlEncoderParser = bodyParser.urlencoded({
    extended: false
});
router.use(cookieParser());
router.use(session({
    secret: "Secret!"
}));
var Connections = mongoose.model('connections', connectionModel.connectionsSchema, 'connections');
var Subconnections = mongoose.model('subconnections', connectionModel.subconnectionsSchema, 'subconnections');
var UserConnectionModel = mongoose.model('userConnections', userConnectionModel1.userConnectionSchema, 'userConnections');


//This get method is to get all the connections and their subconnections
router.get('/', async function(request, response) {

//Checking if user islogged in
    var currentu = '';
    var currentnamee = '';
    if (request.session.theUser) {
        currentu = 'yes';
        currentnamee = request.session.theUser.firstName;
    } else {
        currentu = 'no';
        currentnamee = 'Please Sign in!';
    }
    // getting the data from database
    var connections = await connectionDB.getConnections(Subconnections);
    var subconnections = await connectionDB.getSubconnections(Subconnections);
    var encodedHTML1 = escape(connections);
    var encodedHTML2 = escape(subconnections);
// rendering the connection page
    response.render('connections', {
        allConnections: connections,
        allSubconnections: subconnections,
        currentUser: currentu,
        currentName: currentnamee
    });


});

//this get method is to display a connection of a particular ID
router.get('/connection/:connectionID', async function(request, response) {
    var currentu = '';
    var currentnamee = '';
    var id;
//checking if user is logged in
    if (request.session.theUser) {

        var userData = await userConnectionDB.checkUserHasConnection(Subconnections, request.params.connectionID)
        currentu = 'yes';
        currentnamee = request.session.theUser.firstName;
        if (request.session.theUser.userID === userData.userID) {
            var id = userData.userID
        } else {
            id = null;
        }

    } else {
        currentu = 'no';
        currentnamee = 'Please Sign in!';
        id = null;
    }
    //getting connection data from the database
    var connectionDB = require('../utility/connectionDB.js');
    var data = await connectionDB.getConnection(Subconnections, request.params.connectionID);
    if (data == null) {
        var connections = await connectionDB.getConnections(Subconnections);
        var subconnections = await connectionDB.getSubconnections(Subconnections);

        response.render('connections', {
            allConnections: connections,
            allSubconnections: subconnections,
            currentUser: currentu,
            currentName: currentnamee
        });
    } else {
        let allConnectionsCodes = [];
        if (request.session.theUser && request.session.userProfile && request.session.userProfile.userConnections) {
            let list = request.session.userProfile.userConnections;
            for (let k = 0; k < list.length; k++) {
                allConnectionsCodes.push(list[k].connectionData.connectionID);
            }
        } else {
            allConnectionsCodes = ['NC1', 'NC3'];
        }
//rendering the connection page
        response.render('connection', {
            connection: data,
            currentUser: currentu,
            allConnectionListFeed: allConnectionsCodes,
            currentName: currentnamee,
            id: id
        });
    }
});




module.exports = router;
