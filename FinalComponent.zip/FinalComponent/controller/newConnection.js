var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/Milestone4', {
    useNewUrlParser: true
});
let userProfile = require('../models/userProfile.js');
var userModel1 = require('../models/user.js')
var connectionModel = require('../models/connection.js')
var userConnectionModel1 = require('../models/userConnection.js');
var express = require('express');
var connectionDB = require('../utility/connectionDB.js');

var userConnectionDB = require('../utility/userConnectionDB.js');
var userDB = require('../utility/userDB.js');
var router = express.Router();
var bodyParser = require('body-parser')
var session = require('express-session');
var cookieParser = require('cookie-parser');
const {
    check,
    validationResult,
    sanitizeBody
} = require('express-validator');

var urlEncoderParser = bodyParser.urlencoded({
    extended: false
});
router.use(cookieParser());
router.use(session({
    secret: "Secret!"
}));

var usersModel = mongoose.model('users', userModel1.userSchema, 'userData');
var Connections = mongoose.model('connections', connectionModel.connectionsSchema, 'connections');
var Subconnections = mongoose.model('subconnections', connectionModel.subconnectionsSchema, 'subconnections');
var userConnectionModel = mongoose.model('userConnections', userConnectionModel1.userConnectionSchema, 'userConnections');
//rendering new connection page
router.get('/', function(request, response) {
    if (request.session.theUser) {
        response.render('newConnection', {
            connection: "",
            currentUser: 'yes',
            currentName: request.session.theUser.firstName,
            loginerror: "",
            errorMessages: ""
        })
    } else {
        response.render('login', {
            currentUser: 'no',
            currentName: 'Please Sign in!',
            loginerror: "Please log in to create a new event!"
        });
    }
});
router.get('/modifyConnection', async function(request, response) {

    var connectionDB = require('../utility/connectionDB.js');
    var data = await connectionDB.getConnection(Subconnections, request.query.connectionID);
    var currentu = '';
    var currentnamee = '';

    var id;

    if (request.session.theUser) {

        var userData = await userConnectionDB.checkUserHasConnection(Subconnections, request.query.connectionID)

        currentu = 'yes';
        currentnamee = request.session.theUser.firstName;
        if (request.session.theUser.userID === userData.userID) {
            var id = userData.userID
        } else {
            id = null;
        }

    } else {
        currentu = 'no';
        currentnamee = 'Please Sign in!';
        id = null;
    }

    response.render('newConnection', {
        connection: data,
        currentUser: 'yes',
        currentName: request.session.theUser.firstName,
        loginerror: "",
        errorMessages: ""
    })


});


router.post('/modifyConnection', [urlEncoderParser,
    check('name').custom(name => {
        var isValid = name.match(/^([a-zA-Z]+\s)*[a-zA-Z]+$/);
        if (isValid != null) {
            return true;
        } else {
            return false;
        }
    }).withMessage('Please enter valid State Name.'), sanitizeBody('name').trim().escape(),
    check('topic').custom(name => {
        var isValid = name.match(/^([a-zA-Z]+\s)*[a-zA-Z]+$/);
        if (isValid != null) {
            return true;
        } else {
            return false;
        }
    }).withMessage('Please enter valid City Name.'), sanitizeBody('topic').trim().escape(),
    check('details').custom(name => {
        var isValid = name.match(/^([a-zA-Z]+\s)*[a-zA-Z]+$/);
        if (isValid != null) {
            return true;
        } else {
            return false;
        }
    }).withMessage('Please enter valid description.'), sanitizeBody('details').trim().escape()
], async function(request, response) {

    const errors = validationResult(request);


//This will add a new connection for a specific user

    if (request.body.action == "AddEvent") {
      var currentu = '';
      var currentnamee = '';
      if (request.session.theUser) {
          currentu = 'yes';
          currentnamee = request.session.theUser.firstName;
      } else {
          currentu = 'no';
          currentnamee = 'Please Sign in!';
      }

        if (!errors.isEmpty()) {
            response.render('newConnection', {
                connection: "",
                currentUser: 'no',
                currentName: currentnamee,
                loginerror: "",
                errorMessages: errors.array()
            });
        } else {

            userReqParams = request.body;
            let update = {
                connectionID: userReqParams.name,
                connectionName: userReqParams.topic,
                topic: userReqParams.name,
                details: userReqParams.details,
                date: userReqParams.when,
                time: userReqParams.time,
                address: userReqParams.where,
                hostName: request.session.theUser.firstName,
                userID: request.session.theUser.userID

            };
            var connectionDB = require('../utility/connectionDB.js');
            await userConnectionDB.addConnection(Subconnections, update);

            var connections = await connectionDB.getConnections(Subconnections);
            var subconnections = await connectionDB.getSubconnections(Subconnections);
            response.render('connections', {
                allConnections: connections,
                allSubconnections: subconnections,
                currentUser: currentu,
                currentName: currentnamee
            });
        }
    }
//user can delete the connection they own
    if (request.body.action === 'delete') {
      var currentu = '';
      var currentnamee = '';
      if (request.session.theUser) {
          currentu = 'yes';
          currentnamee = request.session.theUser.firstName;
      } else {
          currentu = 'no';
          currentnamee = 'Please Sign in!';
      }
        await userProfile.removeuserConnection(request.body.connectionID, request.session.theUser.userID, Subconnections);

        var connectionDB = require('../utility/connectionDB.js');
        var connections = await connectionDB.getConnections(Subconnections);
        var subconnections = await connectionDB.getSubconnections(Subconnections);

        response.render('connections', {
            allConnections: connections,
            allSubconnections: subconnections,
            currentUser: currentu,
            currentName: currentnamee
        });
    }
// user can update the connection they own
    if (request.body.action == "UpdateEvent") {
        userReqParams = request.body;
        let update = {
            connectionID: userReqParams.name,
            connectionName: userReqParams.topic,
            topic: userReqParams.name,
            details: userReqParams.details,
            date: userReqParams.when,
            time: userReqParams.time,
            address: userReqParams.where,

        };

        var connectionDB = require('../utility/connectionDB.js');
        await userProfile.updateConnection(Subconnections, request.body.connectionID, update)
        await userProfile.updateuserConnection(userConnectionModel, request.body.connectionID, update)
        var userData = request.session.theUser;
        await userDB.updateUserProfileItems(userConnectionModel, userData.userID)
        var data = await connectionDB.getConnection(Subconnections, request.body.connectionID);
        if (!errors.isEmpty()) {
            response.render('newConnection', {
                connection: data,
                currentUser: 'no',
                currentName: 'Please Sign in!',
                loginerror: "",
                errorMessages: errors.array()
            });
        } else {
            var currentu = '';
            var currentnamee = '';

            var id;

            if (request.session.theUser) {

                var userData = await userConnectionDB.checkUserHasConnection(Subconnections, request.body.connectionID)

                currentu = 'yes';
                currentnamee = request.session.theUser.firstName;
                if (request.session.theUser.userID === userData.userID) {
                    var id = userData.userID
                } else {
                    id = null;
                }

            } else {
                currentu = 'no';
                currentnamee = 'Please Sign in!';
                id = null;
            }
            response.render('connection', {
                connection: data,
                currentUser: currentu,
                currentName: currentnamee,
                id: id
            });
        }

    }


})


module.exports = router;
