var mongoose = require('mongoose');

module.exports.addRSVP = function(db, connectionID, userID, rsvp) {


    return new Promise((resolve, reject) => {
        db.updateOne({
            userID: userID,
            "connectionData.connectionID": connectionID,
        }, {
            $set: {
                rsvp: rsvp
            }
        }).then(data => {
            resolve(data);
        }).catch(err => {
            return reject(err);
        })
    })
}

module.exports.updateRSVP = function(db, connectionID, userID, rsvp) {
    return new Promise((resolve, reject) => {
        db.collection.updateOne({
                userID: userID,
                "connectionData.connectionID": connectionID
            }, {
                $set: {
                    rsvp: rsvp
                }
            })
            .then(data => {
                resolve(data);

            }).catch(err => {
                return reject(err);
            })
    })

}
module.exports.getUserProfile = async function(db, update) {
    return new Promise((resolve, reject) => {
        db.collection.insertMany(update, function(err, data) {
            resolve(data);
        }).catch(err => {
            return reject(err);
        });
    })

}

module.exports.checkUserHasConnection = async function(db, connectionID) {
    return new Promise((resolve, reject) => {
        db.findOne({
            connectionID: connectionID
        }, {
            userID: 1
        }).then(data => {

            resolve(data);

        }).catch(err => {
            return reject(err);
        })
    })
}


module.exports.addConnection = async function(db, update) {

    db.collection.insertOne(update, {
        upsert: true,
        new: true
    }, function(err, data) {

    })
}
