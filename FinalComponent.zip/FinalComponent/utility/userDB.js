var mongoose = require('mongoose');
let userProfile = require('../models/userProfile.js');

let connectionDB = require('../utility/connectionDB');


module.exports.updateUserProfileItems = async function(db, userID) {
    let allItem = await userProfile.getConnections(db, userID);
    return allItem;
};


module.exports.getAllUsers = async function(db) {


    return new Promise((resolve, reject) => {
        db.find({}).then(data => {
            resolve(data[0]);
        }).catch(err => {
            return reject(err);
        })
    })
};



module.exports.getCurrentUser = async function(db, userID) {
    return new Promise((resolve, reject) => {
        db.findOne({
            userID: userID
        }).then(data => {
            for (let i = 0; i < data.length; i++) {
                if (!allConnections.includes(data[i].connectionID)) {
                    var userModel = require('../models/user');
                    userModel = userModel.user(data[i].connectionData, data[i].firstName, data[i].lastName, data[i].email, data[i].addressline1,
                        data[i].addressline2, data[i].city, data[i].state, userData[i].zipcode, userData[i].country);
                    return userModel;
                }
            }
        }).catch(err => {
            return reject(err);
        })
    })
};


module.exports.addUser = async function(db, userID, firstName, lastName, email,
    addressline1, addressline2, city, state, country, zipcode, password, salt) {
    return new Promise((resolve, reject) => {
        db.collection.insert({
            userID: userID,
            firstName: firstName,
            lastName: lastName,
            email: email,
            addressline1: addressline1,
            addressline2: addressline2,
            city: city,
            state: state,
            country: country,
            zipcode: zipcode,
            password: password,
            salt: salt
        }).then(data => {
            resolve(data);
        }).catch(err => {
            return reject(err);
        })
    })


}
