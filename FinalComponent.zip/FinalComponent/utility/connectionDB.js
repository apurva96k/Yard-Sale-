var mongoose = require('mongoose');

module.exports.getSubconnections = async function(db) {
    var allSubconnections = [];
    return new Promise((resolve, reject) => {
        db.find({}).then(data => {
            for (let i = 0; i < data.length; i++) {
                if (!allSubconnections.includes(data[i].connectionID)) {
                    var connectionModel = require('../models/connection');
                    connectionModel = connectionModel.connection(data[i].connectionID, data[i].connectionName, data[i].topic, data[i].details,
                        data[i].date, data[i].time, data[i].hostName, data[i].address);
                    allSubconnections.push(connectionModel);
                }
            }
            resolve(data);

            return allConnections;

        }).catch(err => {
            return reject(err);
        })
    })
};
module.exports.getConnections = async function(db) {


    return new Promise((resolve, reject) => {
        db.find({}).then(data => {
            allConnections = [], scanned = [];
            for (let i = 0; i < data.length; i++) {
                if (scanned[data[i].topic]) continue;
                scanned[data[i].topic] = true;
                allConnections.push(data[i].topic);
            }
            resolve(allConnections);



        }).catch(err => {
            return reject(err);
        })
    })
};



module.exports.getConnection = async function(db, connectionID) {

    return new Promise((resolve, reject) => {
        db.findOne({
            "connectionID": connectionID
        }).then(data => {
            let connectionModel = require('../models/connection');
            connectionModel = connectionModel.connection(data.connectionID, data.connectionName, data.topic, data.details,
                data.date, data.time, data.hostName, data.address);
            resolve(connectionModel);
        }).catch(err => {
            return reject(err);
        })
    });
};
