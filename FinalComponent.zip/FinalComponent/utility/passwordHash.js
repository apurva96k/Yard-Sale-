'use strict';
var crypto = require('crypto');
var genRandomString = function(length) {
    return crypto.randomBytes(Math.ceil(length / 2))
        .toString('hex') /** convert to hexadecimal format */
        .slice(0, length); /** return required number of characters */
};
var sha512 = function(password, salt) {
    var hash = crypto.createHmac('sha512', salt); /** Hashing algorithm sha512 */
    hash.update(password);
    var value = hash.digest('hex');
    return {
        salt: salt,
        passwordHash: value
    };
};

module.exports.saltHashPassword = function(userpassword) {
    var salt = genRandomString(16); /** Gives us salt of length 16 */
    var passwordData = sha512(userpassword, salt);
    return passwordData;

}

//validate user email
module.exports.validateUserEmail = function(db, email) {
    return new Promise((resolve, reject) => {
        db.findOne({
            email: email

        }, {
            userID: 1,
            firstName: 1,
            lastName: 1,
            email: 1,
            addressline1: 1,
            addressline2: 1,
            city: 1,
            state: 1,
            zipcode: 1,
            country: 1
        }).then(data => {
            resolve(data);
        }).catch(err => {
            return reject(err);
        })
    })
};
var validate = function(userpassword, saltFromDb, hashedPassFromDB) {


    var passwordData = sha512(userpassword, saltFromDb);
    if (passwordData.passwordHash === hashedPassFromDB) {
        return true;
    }
    return false;
}

module.exports.validatepassword = function(db, email, userPassword) {
    return new Promise((resolve, reject) => {
        db.findOne({
            email: email
        }).then(data => {
            let flag = validate(userPassword, data.salt, data.password)
            resolve(flag);
        }).catch(err => {
            return reject(err);
        })
    })

}


module.exports.setpassword = function(db, email, salt, hashed) {
    return new Promise((resolve, reject) => {
        db.updateOne({
            email: email
        }, {
            $set: {
                password: hashed,
                salt: salt
            }
        }).then(data => {
            resolve(data);
        }).catch(err => {
            return reject(err);
        })
    })
}
